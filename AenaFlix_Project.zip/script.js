const haramWords = ['dance', 'music', 'nudity'];
const videoFeed = document.getElementById("videoFeed");
const runner = document.getElementById("runner");
let coins = 0;

function isHalal(title) {
  return !haramWords.some(word => title.toLowerCase().includes(word));
}

function uploadVideo() {
  const file = document.getElementById("videoUpload").files[0];
  const title = prompt("Enter a video title:");
  if (!file || !title || !isHalal(title)) {
    alert("Invalid or haram title.");
    return;
  }
  const url = URL.createObjectURL(file);
  const videoCard = document.createElement("div");
  videoCard.innerHTML = `<h4>${title}</h4><video controls src="${url}"></video>`;
  videoFeed.prepend(videoCard);
}

function startGame() {
  let pos = 0;
  const interval = setInterval(() => {
    pos += 10;
    runner.style.left = pos + 'px';
    if (pos >= document.getElementById('gameBox').offsetWidth - 50) {
      clearInterval(interval);
      coins += 10;
      document.getElementById("coins").innerText = coins;
      updateLevel();
    }
  }, 100);
}

function updateLevel() {
  const level = document.getElementById("level");
  if (coins >= 50) level.innerText = "Diamond";
  else if (coins >= 30) level.innerText = "Gold";
  else if (coins >= 20) level.innerText = "Silver";
  else level.innerText = "Bronze";
}

function unlockAdmin() {
  const pass = document.getElementById("devPass").value;
  if (pass === "aenaflix@dev") {
    document.getElementById("adminTools").style.display = 'block';
    alert("Welcome, Developer AenaFlix");
  } else {
    alert("Incorrect Password");
  }
}
